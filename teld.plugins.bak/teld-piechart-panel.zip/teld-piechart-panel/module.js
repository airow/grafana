import { TeldPieChartCtrl } from './piechart_ctrl';

export {
  TeldPieChartCtrl as PanelCtrl
};
